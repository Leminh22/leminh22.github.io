const Message = require("../models/Message");

exports.createMessage = async (req, res) => {
  try {
    const message = new Message(req.body);
    const saved = await message.save();
    res.status(200).json(saved);
  } catch (err) {
    res.status(500).json(err);
  }
};

exports.getMessages = async (req, res) => {
  try {
    const messages = await Message.find({ conversationId: req.params.conversationId });
    res.status(200).json(messages);
  } catch (err) {
    res.status(500).json(err);
  }
};
