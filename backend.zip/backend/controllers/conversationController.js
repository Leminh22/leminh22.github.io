const Conversation = require("../models/Conversation");

exports.createConversation = async (req, res) => {
  const newConv = new Conversation({ members: [req.body.senderId, req.body.receiverId] });
  try {
    const saved = await newConv.save();
    res.status(200).json(saved);
  } catch (err) {
    res.status(500).json(err);
  }
};

exports.getUserConversations = async (req, res) => {
  try {
    const convs = await Conversation.find({ members: { $in: [req.params.userId] } });
    res.status(200).json(convs);
  } catch (err) {
    res.status(500).json(err);
  }
};
