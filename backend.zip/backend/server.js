const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const http = require('http');
const { Server } = require("socket.io");

const authRoute = require('./routes/auth');
const userRoute = require('./routes/users');
const messageRoute = require('./routes/messages');
const convRoute = require('./routes/conversations');

dotenv.config();
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

require('./socket')(io);

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoute);
app.use('/api/users', userRoute);
app.use('/api/message', messageRoute);
app.use('/api/conversation', convRoute);


// DB Connection
const connectDB = require('./config/db');
connectDB();

// Start server
const PORT = process.env.PORT || 8800;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

app.get('/', (req, res) => {
  res.json([
    { sender: 'System', content: 'Chào mừng đến với Zalo chat 🎉' }
  ]);
});
