const router = require("express").Router();
const Message = require('../models/Message');
const { createMessage, getMessages } = require("../controllers/messageController");
// Send Message
router.post("/", async (req, res) => {
  const message = new Message(req.body);
  try {
    const saved = await message.save();
    res.status(200).json(saved);
  } catch (err) {
    res.status(500).json(err);
  }
});

// Get messages by conversationId
router.get("/:conversationId", async (req, res) => {
  try {
    const messages = await Message.find({ conversationId: req.params.conversationId });
    res.status(200).json(messages);
  } catch (err) {
    res.status(500).json(err);
  }
});

module.exports = router;
