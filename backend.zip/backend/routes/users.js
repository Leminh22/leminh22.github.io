const express = require('express');
const router = express.Router();

// Ví dụ lấy tất cả user
router.get('/', (req, res) => {
  // logic lấy user, ví dụ User.find()
  res.send('User list here');
});

module.exports = router;
